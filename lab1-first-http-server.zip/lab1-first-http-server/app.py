from flask import Flask, jsonify, request
import time

app = Flask(__name__)

@app.before_request
def log_request():
    print(
        f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] "
        f"{request.method} {request.path}"
    )


@app.route('/')
def home():
    return 'Добро пожаловать домой'


@app.route('/api/employees')
def employees():
    data = [
        {
            "id": 1,
            "name": "Иван Иванов",
            "position": "Developer"
        },
        {
            "id": 2,
            "name": "Анна Петрова",
            "position": "Designer"
        },
        {
            "id": 3,
            "name": "Сергей Смирнов",
            "position": "Manager"
        }
    ]

    return jsonify(data)

@app.route('/api/offices')
def offices():
    data = [
        {
            "id": 1,
            "city": "Москва",
            "address": "ул. Центральная, 10"
        },
        {
            "id": 2,
            "city": "Санкт-Петербург",
            "address": "Невский проспект, 25"
        },
        {
            "id": 3,
            "city": "Ставрополь",
            "address": "ул. Ленина, 50"
        }
    ]

    return jsonify(data)

@app.route('/api/employees/<int:employee_id>')
def get_employee(employee_id):
    return jsonify({
        "requestedId": employee_id,
        "status": "success"
    })


@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "error": "Not Found"
    }), 404


if __name__ == '__main__':
    app.run(port=3000, debug=True)